exports.ConfirmationPage = class ConfirmationPage {
  constructor(page) {
    this.page = page;
    this.header = page.locator('.complete-header');
  }

  async getHeader() {
    return await this.header.textContent();
  }
};