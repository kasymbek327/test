exports.InventoryPage = class InventoryPage {
  constructor(page) {
    this.page = page;
    this.sortDropdown = page.locator('[data-test="product_sort_container"]');
    this.inventoryItems = page.locator('.inventory_item_price');
    this.addToCartButton = page.locator('[data-test="add-to-cart-sauce-labs-backpack"]');
    this.cartIcon = page.locator('.shopping_cart_link');
  }

  async sortLowToHigh() {
    await this.sortDropdown.selectOption('lohi');
  }

  async getPrices() {
    const prices = await this.inventoryItems.allTextContents();
    return prices.map(p => parseFloat(p.replace('$', '')));
  }

  async addItemToCart() {
    await this.addToCartButton.click();
  }

  async goToCart() {
    await this.cartIcon.click();
  }
};