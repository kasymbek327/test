# SauceDemo E2E Tests

## Установка

```bash
npm install
npx playwright install
```

## Запуск тестов

```bash
npx playwright test
```