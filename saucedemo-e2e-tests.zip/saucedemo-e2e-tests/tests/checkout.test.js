const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { InventoryPage } = require('../pages/InventoryPage');
const { CartPage } = require('../pages/CartPage');
const { CheckoutPage } = require('../pages/CheckoutPage');
const { ConfirmationPage } = require('../pages/ConfirmationPage');

test('Complete purchase with valid info', async ({ page }) => {
  const login = new LoginPage(page);
  const inventory = new InventoryPage(page);
  const cart = new CartPage(page);
  const checkout = new CheckoutPage(page);
  const confirmation = new ConfirmationPage(page);

  await page.goto('https://www.saucedemo.com');
  await login.login('standard_user', 'secret_sauce');
  await inventory.addItemToCart();
  await inventory.goToCart();
  await cart.proceedToCheckout();
  await checkout.fillInfo('John', 'Doe', '12345');
  await checkout.completeOrder();
  const header = await confirmation.getHeader();
  expect(header).toContain('THANK YOU');
});

test('Try to checkout with missing ZIP code', async ({ page }) => {
  const login = new LoginPage(page);
  const inventory = new InventoryPage(page);
  const cart = new CartPage(page);
  const checkout = new CheckoutPage(page);

  await page.goto('https://www.saucedemo.com');
  await login.login('standard_user', 'secret_sauce');
  await inventory.addItemToCart();
  await inventory.goToCart();
  await cart.proceedToCheckout();
  await checkout.fillInfo('John', 'Doe', '');
  const error = await checkout.getErrorMessage();
  expect(error).toContain('Postal Code is required');
});

test('Try to checkout with empty cart', async ({ page }) => {
  const login = new LoginPage(page);
  const inventory = new InventoryPage(page);
  const cart = new CartPage(page);

  await page.goto('https://www.saucedemo.com');
  await login.login('standard_user', 'secret_sauce');
  await inventory.goToCart();
  await cart.proceedToCheckout();
  await expect(page.locator('input[data-test="firstName"]')).toBeVisible();
});