const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { InventoryPage } = require('../pages/InventoryPage');

test('Sort products by price (low to high)', async ({ page }) => {
  const login = new LoginPage(page);
  const inventory = new InventoryPage(page);
  await page.goto('https://www.saucedemo.com');
  await login.login('standard_user', 'secret_sauce');
  await inventory.sortLowToHigh();
  const prices = await inventory.getPrices();
  const sorted = [...prices].sort((a, b) => a - b);
  expect(prices).toEqual(sorted);
});