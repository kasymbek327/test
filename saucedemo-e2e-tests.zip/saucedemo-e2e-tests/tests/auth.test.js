const { test, expect } = require('@playwright/test');

test('Access checkout page without login redirects to login', async ({ page }) => {
  await page.goto('https://www.saucedemo.com/checkout-step-one.html');
  await expect(page).toHaveURL(/.*saucedemo\.com/);
  await expect(page.locator('[data-test="login-button"]')).toBeVisible();
});