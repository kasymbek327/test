module.exports = {
  use: {
    headless: true,
    baseURL: 'https://www.saucedemo.com',
  },
  timeout: 60000
};